vec4 color(vec4 graphicsColor, sampler2D image, vec2 uv) 
{    
    return vec4(0.0, 1.0, 0.67, 0.33);    
}
