# lilneemit
VR MF Jam #1 entry

Shaders/lighting cloned and tweaked from Tangram
